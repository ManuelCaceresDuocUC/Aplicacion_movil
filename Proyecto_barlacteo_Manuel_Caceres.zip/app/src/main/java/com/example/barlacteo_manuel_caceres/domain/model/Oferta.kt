package com.example.barlacteo_manuel_caceres.domain.model

data class Oferta(
    val id: String,
    val titulo: String,
    val descripcion: String,
    val imagenUrl: String
)
